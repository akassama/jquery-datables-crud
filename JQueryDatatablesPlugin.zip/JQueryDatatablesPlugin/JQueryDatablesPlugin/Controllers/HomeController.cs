﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using JQueryDatablesPlugin.Models;
using Microsoft.EntityFrameworkCore.Internal;

namespace JQueryDatablesPlugin.Controllers
{
    public class HomeController : Controller
    {
        AppFunctions functions = new AppFunctions();
        private readonly DBConnection _context;

        public HomeController(DBConnection context)
        {
            _context = context;
        }

        // GET: Employee
        public async Task<IActionResult> Index()
        {
            return View(await _context.Employee.ToListAsync());
        }
        

        // POST: Employee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmployeeModel employeeModel)
        {
            //get input fields and set viewbag data
            string FirstName = HttpContext.Request.Form["FirstName"];
            ViewBag.FirstName = FirstName;

            string LastName = HttpContext.Request.Form["LastName"];
            ViewBag.LastName = LastName;

            string Position = HttpContext.Request.Form["Position"];
            ViewBag.Position = Position;

            string OfficeLocation = HttpContext.Request.Form["OfficeLocation"];
            ViewBag.OfficeLocation = OfficeLocation;

            string DateOfBirth = HttpContext.Request.Form["DateOfBirth"];
            ViewBag.DateOfBirth = (!string.IsNullOrEmpty(DateOfBirth)) ? Convert.ToDateTime(DateOfBirth).ToString("yyyy-MM-dd") : "";

            string StartDate = HttpContext.Request.Form["StartDate"];
            ViewBag.FirstName = FirstName;

            string Salary = HttpContext.Request.Form["Salary"];
            ViewBag.Salary = Salary;

            //validate inputs
            string[] ValidationInputs = { FirstName, LastName, Position, OfficeLocation, DateOfBirth, StartDate, Salary };
            if (!functions.ValidateInputs(ValidationInputs))
            {
                TempData["ErrorMessage"] = "Validation error. Missing required field(s).";
                TempData["DisplayModal"] = "addEmployeeModal";
                return RedirectToAction("Index", "Home");
            }

            try
            {
                employeeModel.EmployeeID = functions.GetGuid();
                employeeModel.FirstName = FirstName;
                employeeModel.LastName = LastName;
                employeeModel.Position = Position;
                employeeModel.OfficeLocation = OfficeLocation;
                employeeModel.DateOfBirth = Convert.ToDateTime(DateOfBirth);
                employeeModel.StartDate = Convert.ToDateTime(StartDate);
                employeeModel.Salary = Salary;
                employeeModel.UpdateDate = DateTime.Now;
                employeeModel.DateAdded = DateTime.Now;

                _context.Add(employeeModel);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Record added successfully.";

                return RedirectToAction("Index", "Home");

            }
            catch (Exception)
            {
                //handle exception here
                TempData["ErrorMessage"] = "There was an error processing your request. ";
                TempData["DisplayModal"] = "addEmployeeModal";
            }

            return RedirectToAction("Index", "Home");

        }


        // POST: Employee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EmployeeModel employeeModel)
        {
            string id = HttpContext.Request.Form["EditEmployeeID"];
            if (!_context.Employee.Any(s=> s.EmployeeID == id))
            {
                TempData["ErrorMessage"] = "Record not found.";
                return RedirectToAction("Index", "Home");
            }


            //get input fields and set viewbag data
            string FirstName = HttpContext.Request.Form["EditFirstName"];

            string LastName = HttpContext.Request.Form["EditLastName"];

            string Position = HttpContext.Request.Form["EditPosition"];

            string OfficeLocation = HttpContext.Request.Form["EditOfficeLocation"];

            string DateOfBirth = HttpContext.Request.Form["EditDateOfBirth"];

            string StartDate = HttpContext.Request.Form["EditStartDate"];

            string Salary = HttpContext.Request.Form["EditSalary"];

            //validate inputs
            string[] ValidationInputs = { FirstName, LastName, Position, OfficeLocation, DateOfBirth, StartDate, Salary };
            if (!functions.ValidateInputs(ValidationInputs))
            {
                TempData["ErrorMessage"] = "Validation error. Missing required field(s).";
                return RedirectToAction("Index", "Home");
            }

            try 
            {
                employeeModel.EmployeeID = id;
                employeeModel.FirstName = FirstName;
                employeeModel.LastName = LastName;
                employeeModel.Position = Position;
                employeeModel.OfficeLocation = OfficeLocation;
                employeeModel.DateOfBirth = Convert.ToDateTime(DateOfBirth);
                employeeModel.StartDate = Convert.ToDateTime(StartDate);
                employeeModel.Salary = Salary;
                employeeModel.UpdateDate = DateTime.Now;

                try
                {
                    _context.Update(employeeModel);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Record updated successfully.";
                    return RedirectToAction("Index", "Home");
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeModelExists(employeeModel.EmployeeID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        //handle exception here
                        TempData["ErrorMessage"] = "There was an error processing your request. ";
                        TempData["DisplayModal"] = "editEmployeeModal";
                    }
                }
            }
            catch (Exception)
            {
                //handle exception here
                TempData["ErrorMessage"] = "There was an error processing your request. ";
                TempData["DisplayModal"] = "editEmployeeModal";
            }
            return RedirectToAction("Index", "Home");
        }


        // POST: Employee/Delete/5
        [HttpPost, ActionName("RemoveEmployee")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveEmployee()
        {
            string id = HttpContext.Request.Form["RemoveEmployeeID"];
            if (!_context.Employee.Any(s => s.EmployeeID == id))
            {
                TempData["ErrorMessage"] = "Record not found.";
                return RedirectToAction("Index", "Home");
            }

            try
            {
                var employeeModel = await _context.Employee.FindAsync(id);
                _context.Employee.Remove(employeeModel);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Record removed successfully.";
                return RedirectToAction("Index", "Home");
            }
            catch (Exception)
            {
                //handle exception here
                TempData["ErrorMessage"] = "There was an error processing your request. ";
                TempData["DisplayModal"] = "removeEmployeeModal";
            }

            return RedirectToAction("Index", "Home");
        }

        private bool EmployeeModelExists(string id)
        {
            return _context.Employee.Any(e => e.EmployeeID == id);
        }

        // GET: Documentation
        public async Task<IActionResult> Documentation()
        {
            return View();
        }
    }
}
