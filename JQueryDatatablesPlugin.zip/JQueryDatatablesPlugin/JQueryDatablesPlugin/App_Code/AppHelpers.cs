﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AppHelpers.App_Code
{
    public static class DateHelper
    {
        //Get Employee Age
        /// <summary>
        /// Generates employee age from date of birth
        /// </summary>
        /// <returns>Age as string</returns>
        public static string GetAge(DateTime date_of_birth)
        {
            if (date_of_birth != null)
            {
                // Get today's date.
                var today = DateTime.Today;

                // Calculate the age.
                var age = today.Year - date_of_birth.Year;

                // Go back to the year in which the person was born in case of a leap year
                if (date_of_birth.Date > today.AddYears(-age)) age--;

                return age.ToString();
            }
            return null;
        }

        //Convert date to yyyy-MM-dd format (nullable)
        /// <summary>
        /// Convert date to yyyy-MM-dd format
        /// </summary>
        /// <returns>Date as string</returns>
        public static string InpuDateFormat(DateTime? input_date)
        {
            if(input_date != null)
            {
                return Convert.ToDateTime(input_date).ToString("yyyy-MM-dd");
            }
            return null;
        }

        //Convert date to yyyy-MM-dd format
        /// <summary>
        /// Convert date to yyyy-MM-dd format
        /// </summary>
        /// <returns>Date as string</returns>
        public static string InpuDateFormat(DateTime input_date)
        {
            if (input_date != null)
            {
                return Convert.ToDateTime(input_date).ToString("yyyy-MM-dd");
            }
            return null;
        }
    }

    public static class DataHelper
    {
        //Formats nummber
        /// <summary>
        ///  Formats the number adding a comma per every thousand
        /// </summary>
        /// <returns>Number as string with comma if above 1K</returns>
        public static string FormatSalary(string number)
        {
            if (!string.IsNullOrEmpty(number))
            {
                try
                {
                    return Int32.Parse(number).ToString("#,##0");
                }
                catch (Exception)
                {
                    //handle error here
                }
            }
            return null;
        }
    }

}
