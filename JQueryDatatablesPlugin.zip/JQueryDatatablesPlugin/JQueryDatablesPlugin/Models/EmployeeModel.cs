﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JQueryDatablesPlugin.Models
{
    [Table("Employee")]
    public class EmployeeModel
    {
        [Key]
        [Display(Name = "Employee ID")]
        [Column(TypeName = "varchar(250)")]
        public string EmployeeID { get; set; }

        [Required]
        [Display(Name = "First Name")]
        [Column(TypeName = "varchar(100)")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        [Column(TypeName = "varchar(100)")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Position")]
        [Column(TypeName = "varchar(250)")]
        public string Position { get; set; }

        [Required]
        [Display(Name = "Office")]
        [Column(TypeName = "varchar(250)")]
        public string OfficeLocation { get; set; }

        [Required]
        [Display(Name = "Date of Birth")]
        [Column(TypeName = "date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; }

        [Required]
        [Display(Name = "Start Date")]
        [Column(TypeName = "date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime StartDate { get; set; }

        [Required]
        [Display(Name = "Salary")]
        [Column(TypeName = "varchar(50)")]
        public string Salary { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Update Date")]
        public DateTime? UpdateDate { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Date Added")]
        public DateTime? DateAdded { get; set; } = DateTime.Now;
    }
}
