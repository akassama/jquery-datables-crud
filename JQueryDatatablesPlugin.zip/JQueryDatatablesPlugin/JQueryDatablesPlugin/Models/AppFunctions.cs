﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JQueryDatablesPlugin.Models
{
    public class AppFunctions
    {
        //Generates GUID
        /// <summary>
        /// Generating GUID using the Guid.NewGuid() method
        /// </summary>
        /// <returns>GUID as string</returns>
        public string GetGuid()
        {
            Guid obj = Guid.NewGuid();
            return obj.ToString();
        }


        //Validate required inputs 
        /// <summary>
        /// Validates array of inputs for not null
        /// </summary>
        /// <returns>boolean</returns>
        public bool ValidateInputs(string[] inputs)
        {
            // Loop over and check if empty.
            for (int i = 0; i < inputs.Length; i++)
            {
                if (string.IsNullOrEmpty(inputs[i]))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
