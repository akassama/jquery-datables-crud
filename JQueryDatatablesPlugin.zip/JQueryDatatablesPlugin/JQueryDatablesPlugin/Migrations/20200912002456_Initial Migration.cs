﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace JQueryDatablesPlugin.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    EmployeeID = table.Column<string>(type: "varchar(250)", nullable: false),
                    FirstName = table.Column<string>(type: "varchar(100)", nullable: false),
                    LastName = table.Column<string>(type: "varchar(100)", nullable: false),
                    Position = table.Column<string>(type: "varchar(250)", nullable: false),
                    OfficeLocation = table.Column<string>(type: "varchar(250)", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "date", nullable: false),
                    StartDate = table.Column<DateTime>(type: "date", nullable: false),
                    Salary = table.Column<string>(type: "varchar(50)", nullable: false),
                    UpdateDate = table.Column<DateTime>(nullable: false),
                    DateAdded = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.EmployeeID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employee");
        }
    }
}
