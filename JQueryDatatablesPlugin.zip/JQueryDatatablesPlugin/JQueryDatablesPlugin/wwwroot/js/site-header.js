﻿// Document ready functions
$(document).ready(function () {
    //set modal value on click events
    //View Employee Modal
    $(".view-employee").click(function () {
        //get clicked element values
        var empFName = $(this).data("emp-fname");
        var empLName = $(this).data("emp-lname");
        var empPosition = $(this).data("emp-position");
        var empOffice = $(this).data("emp-office");
        var empDOB = $(this).data("emp-dob");
        var empSDate = $(this).data("emp-sdate");
        var empSalary = $(this).data("emp-salary");
        var empUDate = $(this).data("emp-udate");
        var empADate = $(this).data("emp-adate");

        //set view modal data
        $("#ViewFirstName").val(empFName);
        $("#ViewLastName").val(empLName);
        $("#ViewPosition").val(empPosition);
        $("#ViewOfficeLocation").val(empOffice);
        $("#ViewDateOfBirth").val(empDOB);
        $("#ViewStartDate").val(empSDate);
        $("#ViewSalary").val(empSalary);
        $("#ViewUpdateDate").val(empUDate);
        $("#ViewDateAdded").val(empADate);

        $('#viewEmployeeModal').modal('show');
    });

    //Edit Employee Modal
    $(".edit-employee").click(function () {
        //get clicked element values
        var empID = $(this).data("emp-id");
        var empFName = $(this).data("emp-fname");
        var empLName = $(this).data("emp-lname");
        var empPosition = $(this).data("emp-position");
        var empOffice = $(this).data("emp-office");
        var empDOB = $(this).data("emp-dob");
        var empSDate = $(this).data("emp-sdate");
        var empSalary = $(this).data("emp-salary");

        //set view modal data
        $("#EditEmployeeID").val(empID);
        $("#EditFirstName").val(empFName);
        $("#EditLastName").val(empLName);
        $("#EditPosition").val(empPosition);
        $("#EditOfficeLocation").val(empOffice);
        $("#EditDateOfBirth").val(empDOB);
        $("#EditStartDate").val(empSDate);
        $("#EditSalary").val(empSalary);

        $('#editEmployeeModal').modal('show');
    });

    //Remove Employee Modal
    $(".remove-employee").click(function () {
        //get clicked element values
        var empID = $(this).data("emp-id");
        var empFName = $(this).data("emp-fname");
        var empLName = $(this).data("emp-lname");

        //set view modal data
        $("#RemoveEmployeeID").val(empID);
        $("#RemoveEmployeeName").text(empFName + " " + empLName);

        $('#removeEmployeeModal').modal('show');
    });


    // set input filters.
    //allows only decimals for input
    $('.decimal-only').keyup(function () {
        var val = $(this).val();
        if (isNaN(val)) {
            val = val.replace(/[^0-9\.]/g, '');
            if (val.split('.').length > 2)
                val = val.replace(/\.+$/, "");
        }
        $(this).val(val);
    });  
});